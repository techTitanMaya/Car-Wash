﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Venda_Boulevard__VB__Auto_Centre
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnBegin_Click(object sender, EventArgs e)
        {
            Form2 formCalculation = new Form2();  //instantiate the second form in the first
            formCalculation.Show();
        }

        private void btnWash_Click(object sender, EventArgs e)
        {
            Form4 formCarWash = new Form4();
            formCarWash.Show();
        }
    }
}
