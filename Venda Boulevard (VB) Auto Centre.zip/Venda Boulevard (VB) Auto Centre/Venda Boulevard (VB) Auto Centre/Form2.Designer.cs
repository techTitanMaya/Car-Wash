﻿namespace Venda_Boulevard__VB__Auto_Centre
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.groupBoxAccesories = new System.Windows.Forms.GroupBox();
            this.checkBoxNavigation = new System.Windows.Forms.CheckBox();
            this.checkBoxLeather = new System.Windows.Forms.CheckBox();
            this.checkBoxStereo = new System.Windows.Forms.CheckBox();
            this.groupBoxExterior = new System.Windows.Forms.GroupBox();
            this.radioButtonDetailing = new System.Windows.Forms.RadioButton();
            this.radioButtonPearlized = new System.Windows.Forms.RadioButton();
            this.radioButtonStandard = new System.Windows.Forms.RadioButton();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mainMenuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.calculateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutUsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblPrice = new System.Windows.Forms.Label();
            this.txtBoxPrice = new System.Windows.Forms.TextBox();
            this.lblAccesoriesFinish = new System.Windows.Forms.Label();
            this.labelSubtotal = new System.Windows.Forms.Label();
            this.txtBoxAccFin = new System.Windows.Forms.TextBox();
            this.txtBoxSubtotal = new System.Windows.Forms.TextBox();
            this.lblTax = new System.Windows.Forms.Label();
            this.txtBoxTax = new System.Windows.Forms.TextBox();
            this.txtBoxTotal = new System.Windows.Forms.TextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblAllowance = new System.Windows.Forms.Label();
            this.txtBoxAllowance = new System.Windows.Forms.TextBox();
            this.lblDue = new System.Windows.Forms.Label();
            this.txtBoxDue = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.printPreviewDialogCalculation = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocumentCalculation = new System.Drawing.Printing.PrintDocument();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBoxAccesories.SuspendLayout();
            this.groupBoxExterior.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxAccesories
            // 
            this.groupBoxAccesories.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxAccesories.Controls.Add(this.checkBoxNavigation);
            this.groupBoxAccesories.Controls.Add(this.checkBoxLeather);
            this.groupBoxAccesories.Controls.Add(this.checkBoxStereo);
            this.groupBoxAccesories.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxAccesories.ForeColor = System.Drawing.Color.Black;
            this.groupBoxAccesories.Location = new System.Drawing.Point(21, 240);
            this.groupBoxAccesories.Name = "groupBoxAccesories";
            this.groupBoxAccesories.Size = new System.Drawing.Size(211, 143);
            this.groupBoxAccesories.TabIndex = 1;
            this.groupBoxAccesories.TabStop = false;
            this.groupBoxAccesories.Text = "Accesories";
            // 
            // checkBoxNavigation
            // 
            this.checkBoxNavigation.AutoSize = true;
            this.checkBoxNavigation.BackColor = System.Drawing.Color.Transparent;
            this.checkBoxNavigation.ForeColor = System.Drawing.Color.Black;
            this.checkBoxNavigation.Location = new System.Drawing.Point(3, 112);
            this.checkBoxNavigation.Name = "checkBoxNavigation";
            this.checkBoxNavigation.Size = new System.Drawing.Size(171, 20);
            this.checkBoxNavigation.TabIndex = 2;
            this.checkBoxNavigation.Text = "Computer Navigation";
            this.checkBoxNavigation.UseVisualStyleBackColor = false;
            // 
            // checkBoxLeather
            // 
            this.checkBoxLeather.AutoSize = true;
            this.checkBoxLeather.Location = new System.Drawing.Point(3, 67);
            this.checkBoxLeather.Name = "checkBoxLeather";
            this.checkBoxLeather.Size = new System.Drawing.Size(130, 20);
            this.checkBoxLeather.TabIndex = 1;
            this.checkBoxLeather.Text = "Leather Interior";
            this.checkBoxLeather.UseVisualStyleBackColor = true;
            // 
            // checkBoxStereo
            // 
            this.checkBoxStereo.AutoSize = true;
            this.checkBoxStereo.Location = new System.Drawing.Point(3, 20);
            this.checkBoxStereo.Name = "checkBoxStereo";
            this.checkBoxStereo.Size = new System.Drawing.Size(127, 20);
            this.checkBoxStereo.TabIndex = 0;
            this.checkBoxStereo.Text = "Stereo System";
            this.checkBoxStereo.UseVisualStyleBackColor = true;
            // 
            // groupBoxExterior
            // 
            this.groupBoxExterior.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxExterior.Controls.Add(this.radioButtonDetailing);
            this.groupBoxExterior.Controls.Add(this.radioButtonPearlized);
            this.groupBoxExterior.Controls.Add(this.radioButtonStandard);
            this.groupBoxExterior.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxExterior.ForeColor = System.Drawing.Color.Black;
            this.groupBoxExterior.Location = new System.Drawing.Point(21, 38);
            this.groupBoxExterior.Name = "groupBoxExterior";
            this.groupBoxExterior.Size = new System.Drawing.Size(211, 147);
            this.groupBoxExterior.TabIndex = 3;
            this.groupBoxExterior.TabStop = false;
            this.groupBoxExterior.Text = "Exterior Finish";
            // 
            // radioButtonDetailing
            // 
            this.radioButtonDetailing.AutoSize = true;
            this.radioButtonDetailing.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonDetailing.Location = new System.Drawing.Point(6, 103);
            this.radioButtonDetailing.Name = "radioButtonDetailing";
            this.radioButtonDetailing.Size = new System.Drawing.Size(171, 20);
            this.radioButtonDetailing.TabIndex = 4;
            this.radioButtonDetailing.TabStop = true;
            this.radioButtonDetailing.Text = "Customized Detailing";
            this.radioButtonDetailing.UseVisualStyleBackColor = true;
            // 
            // radioButtonPearlized
            // 
            this.radioButtonPearlized.AutoSize = true;
            this.radioButtonPearlized.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonPearlized.Location = new System.Drawing.Point(6, 60);
            this.radioButtonPearlized.Name = "radioButtonPearlized";
            this.radioButtonPearlized.Size = new System.Drawing.Size(91, 20);
            this.radioButtonPearlized.TabIndex = 3;
            this.radioButtonPearlized.TabStop = true;
            this.radioButtonPearlized.Text = "Pearlized";
            this.radioButtonPearlized.UseVisualStyleBackColor = true;
            // 
            // radioButtonStandard
            // 
            this.radioButtonStandard.AutoSize = true;
            this.radioButtonStandard.BackColor = System.Drawing.Color.Transparent;
            this.radioButtonStandard.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonStandard.ForeColor = System.Drawing.Color.Black;
            this.radioButtonStandard.Location = new System.Drawing.Point(6, 20);
            this.radioButtonStandard.Name = "radioButtonStandard";
            this.radioButtonStandard.Size = new System.Drawing.Size(88, 20);
            this.radioButtonStandard.TabIndex = 2;
            this.radioButtonStandard.TabStop = true;
            this.radioButtonStandard.Text = "Standard";
            this.radioButtonStandard.UseVisualStyleBackColor = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.calculateToolStripMenuItem,
            this.printToolStripMenuItem,
            this.aboutUsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 21;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mainMenuToolStripMenuItem,
            this.closeToolStripMenuItem,
            this.closeToolStripMenuItem1});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // mainMenuToolStripMenuItem
            // 
            this.mainMenuToolStripMenuItem.Name = "mainMenuToolStripMenuItem";
            this.mainMenuToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.mainMenuToolStripMenuItem.Text = "Help";
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.closeToolStripMenuItem.Text = "Home page";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem1
            // 
            this.closeToolStripMenuItem1.Name = "closeToolStripMenuItem1";
            this.closeToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.closeToolStripMenuItem1.Text = "Close";
            this.closeToolStripMenuItem1.Click += new System.EventHandler(this.closeToolStripMenuItem1_Click);
            // 
            // calculateToolStripMenuItem
            // 
            this.calculateToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clearToolStripMenuItem,
            this.clearToolStripMenuItem1});
            this.calculateToolStripMenuItem.Name = "calculateToolStripMenuItem";
            this.calculateToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.calculateToolStripMenuItem.Text = "Calculate";
            // 
            // clearToolStripMenuItem
            // 
            this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            this.clearToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.clearToolStripMenuItem.Text = "Calculate ";
            this.clearToolStripMenuItem.Click += new System.EventHandler(this.clearToolStripMenuItem_Click);
            // 
            // clearToolStripMenuItem1
            // 
            this.clearToolStripMenuItem1.Name = "clearToolStripMenuItem1";
            this.clearToolStripMenuItem1.Size = new System.Drawing.Size(126, 22);
            this.clearToolStripMenuItem1.Text = "Clear";
            this.clearToolStripMenuItem1.Click += new System.EventHandler(this.clearToolStripMenuItem1_Click);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printToolStripMenuItem1});
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.printToolStripMenuItem.Text = "Print";
            // 
            // printToolStripMenuItem1
            // 
            this.printToolStripMenuItem1.Name = "printToolStripMenuItem1";
            this.printToolStripMenuItem1.Size = new System.Drawing.Size(99, 22);
            this.printToolStripMenuItem1.Text = "Print";
            this.printToolStripMenuItem1.Click += new System.EventHandler(this.printToolStripMenuItem1_Click);
            // 
            // aboutUsToolStripMenuItem
            // 
            this.aboutUsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpToolStripMenuItem});
            this.aboutUsToolStripMenuItem.Name = "aboutUsToolStripMenuItem";
            this.aboutUsToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.aboutUsToolStripMenuItem.Text = "About us";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.BackColor = System.Drawing.Color.Transparent;
            this.lblPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.ForeColor = System.Drawing.Color.Black;
            this.lblPrice.Location = new System.Drawing.Point(541, 57);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(110, 15);
            this.lblPrice.TabIndex = 22;
            this.lblPrice.Text = "Car Sales Price:";
            // 
            // txtBoxPrice
            // 
            this.txtBoxPrice.Location = new System.Drawing.Point(668, 52);
            this.txtBoxPrice.Name = "txtBoxPrice";
            this.txtBoxPrice.Size = new System.Drawing.Size(100, 20);
            this.txtBoxPrice.TabIndex = 23;
            // 
            // lblAccesoriesFinish
            // 
            this.lblAccesoriesFinish.AutoSize = true;
            this.lblAccesoriesFinish.BackColor = System.Drawing.Color.Transparent;
            this.lblAccesoriesFinish.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccesoriesFinish.ForeColor = System.Drawing.Color.Black;
            this.lblAccesoriesFinish.Location = new System.Drawing.Point(515, 99);
            this.lblAccesoriesFinish.Name = "lblAccesoriesFinish";
            this.lblAccesoriesFinish.Size = new System.Drawing.Size(136, 15);
            this.lblAccesoriesFinish.TabIndex = 24;
            this.lblAccesoriesFinish.Text = "Accesories && Finish:";
            // 
            // labelSubtotal
            // 
            this.labelSubtotal.AutoSize = true;
            this.labelSubtotal.BackColor = System.Drawing.Color.Transparent;
            this.labelSubtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSubtotal.ForeColor = System.Drawing.Color.Black;
            this.labelSubtotal.Location = new System.Drawing.Point(587, 140);
            this.labelSubtotal.Name = "labelSubtotal";
            this.labelSubtotal.Size = new System.Drawing.Size(64, 15);
            this.labelSubtotal.TabIndex = 25;
            this.labelSubtotal.Text = "Subtotal:";
            // 
            // txtBoxAccFin
            // 
            this.txtBoxAccFin.Location = new System.Drawing.Point(668, 94);
            this.txtBoxAccFin.Name = "txtBoxAccFin";
            this.txtBoxAccFin.ReadOnly = true;
            this.txtBoxAccFin.Size = new System.Drawing.Size(100, 20);
            this.txtBoxAccFin.TabIndex = 26;
            // 
            // txtBoxSubtotal
            // 
            this.txtBoxSubtotal.Location = new System.Drawing.Point(668, 139);
            this.txtBoxSubtotal.Name = "txtBoxSubtotal";
            this.txtBoxSubtotal.ReadOnly = true;
            this.txtBoxSubtotal.Size = new System.Drawing.Size(100, 20);
            this.txtBoxSubtotal.TabIndex = 27;
            // 
            // lblTax
            // 
            this.lblTax.AutoSize = true;
            this.lblTax.BackColor = System.Drawing.Color.Transparent;
            this.lblTax.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTax.ForeColor = System.Drawing.Color.Black;
            this.lblTax.Location = new System.Drawing.Point(535, 181);
            this.lblTax.Name = "lblTax";
            this.lblTax.Size = new System.Drawing.Size(116, 15);
            this.lblTax.TabIndex = 28;
            this.lblTax.Text = "Sales Tax (15%):";
            // 
            // txtBoxTax
            // 
            this.txtBoxTax.Location = new System.Drawing.Point(668, 180);
            this.txtBoxTax.Name = "txtBoxTax";
            this.txtBoxTax.ReadOnly = true;
            this.txtBoxTax.Size = new System.Drawing.Size(100, 20);
            this.txtBoxTax.TabIndex = 29;
            // 
            // txtBoxTotal
            // 
            this.txtBoxTotal.Location = new System.Drawing.Point(668, 224);
            this.txtBoxTotal.Name = "txtBoxTotal";
            this.txtBoxTotal.ReadOnly = true;
            this.txtBoxTotal.Size = new System.Drawing.Size(100, 20);
            this.txtBoxTotal.TabIndex = 30;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.BackColor = System.Drawing.Color.Transparent;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.ForeColor = System.Drawing.Color.Black;
            this.lblTotal.Location = new System.Drawing.Point(608, 229);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(43, 15);
            this.lblTotal.TabIndex = 31;
            this.lblTotal.Text = "Total:";
            // 
            // lblAllowance
            // 
            this.lblAllowance.AutoSize = true;
            this.lblAllowance.BackColor = System.Drawing.Color.Black;
            this.lblAllowance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAllowance.ForeColor = System.Drawing.Color.Honeydew;
            this.lblAllowance.Location = new System.Drawing.Point(517, 279);
            this.lblAllowance.Name = "lblAllowance";
            this.lblAllowance.Size = new System.Drawing.Size(134, 15);
            this.lblAllowance.TabIndex = 32;
            this.lblAllowance.Text = "Trade-in Allowance:";
            // 
            // txtBoxAllowance
            // 
            this.txtBoxAllowance.Location = new System.Drawing.Point(668, 274);
            this.txtBoxAllowance.Name = "txtBoxAllowance";
            this.txtBoxAllowance.Size = new System.Drawing.Size(100, 20);
            this.txtBoxAllowance.TabIndex = 33;
            // 
            // lblDue
            // 
            this.lblDue.AutoSize = true;
            this.lblDue.BackColor = System.Drawing.Color.Transparent;
            this.lblDue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDue.ForeColor = System.Drawing.Color.Black;
            this.lblDue.Location = new System.Drawing.Point(562, 323);
            this.lblDue.Name = "lblDue";
            this.lblDue.Size = new System.Drawing.Size(89, 15);
            this.lblDue.TabIndex = 34;
            this.lblDue.Text = "Amount Due:";
            // 
            // txtBoxDue
            // 
            this.txtBoxDue.Location = new System.Drawing.Point(668, 318);
            this.txtBoxDue.Name = "txtBoxDue";
            this.txtBoxDue.ReadOnly = true;
            this.txtBoxDue.Size = new System.Drawing.Size(100, 20);
            this.txtBoxDue.TabIndex = 35;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(644, 386);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(124, 52);
            this.btnSearch.TabIndex = 36;
            this.btnSearch.Text = "Search Parts to Purchase";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // printPreviewDialogCalculation
            // 
            this.printPreviewDialogCalculation.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialogCalculation.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialogCalculation.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialogCalculation.Enabled = true;
            this.printPreviewDialogCalculation.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialogCalculation.Icon")));
            this.printPreviewDialogCalculation.Name = "printPreviewDialogCalculation";
            this.printPreviewDialogCalculation.Visible = false;
            // 
            // printDocumentCalculation
            // 
            this.printDocumentCalculation.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocumentCalculation_PrintPage);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.helpToolStripMenuItem.Text = "More Infomration";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtBoxDue);
            this.Controls.Add(this.lblDue);
            this.Controls.Add(this.txtBoxAllowance);
            this.Controls.Add(this.lblAllowance);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.txtBoxTotal);
            this.Controls.Add(this.txtBoxTax);
            this.Controls.Add(this.lblTax);
            this.Controls.Add(this.txtBoxSubtotal);
            this.Controls.Add(this.txtBoxAccFin);
            this.Controls.Add(this.labelSubtotal);
            this.Controls.Add(this.lblAccesoriesFinish);
            this.Controls.Add(this.txtBoxPrice);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.groupBoxExterior);
            this.Controls.Add(this.groupBoxAccesories);
            this.Name = "Form2";
            this.Text = "VB Auto Center";
            this.groupBoxAccesories.ResumeLayout(false);
            this.groupBoxAccesories.PerformLayout();
            this.groupBoxExterior.ResumeLayout(false);
            this.groupBoxExterior.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.GroupBox groupBoxAccesories;
        public System.Windows.Forms.CheckBox checkBoxNavigation;
        public System.Windows.Forms.CheckBox checkBoxLeather;
        public System.Windows.Forms.CheckBox checkBoxStereo;
        public System.Windows.Forms.GroupBox groupBoxExterior;
        public System.Windows.Forms.RadioButton radioButtonDetailing;
        public System.Windows.Forms.RadioButton radioButtonPearlized;
        public System.Windows.Forms.RadioButton radioButtonStandard;
        private System.Windows.Forms.MenuStrip menuStrip1;
        public System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem mainMenuToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem1;
        public System.Windows.Forms.ToolStripMenuItem calculateToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem aboutUsToolStripMenuItem;
        public System.Windows.Forms.Label lblPrice;
        public System.Windows.Forms.TextBox txtBoxPrice;
        public System.Windows.Forms.Label lblAccesoriesFinish;
        public System.Windows.Forms.Label labelSubtotal;
        public System.Windows.Forms.TextBox txtBoxAccFin;
        public System.Windows.Forms.TextBox txtBoxSubtotal;
        public System.Windows.Forms.Label lblTax;
        public System.Windows.Forms.TextBox txtBoxTax;
        public System.Windows.Forms.TextBox txtBoxTotal;
        public System.Windows.Forms.Label lblTotal;
        public System.Windows.Forms.Label lblAllowance;
        public System.Windows.Forms.TextBox txtBoxAllowance;
        public System.Windows.Forms.Label lblDue;
        public System.Windows.Forms.TextBox txtBoxDue;
        private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem1;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialogCalculation;
        private System.Drawing.Printing.PrintDocument printDocumentCalculation;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
    }
}