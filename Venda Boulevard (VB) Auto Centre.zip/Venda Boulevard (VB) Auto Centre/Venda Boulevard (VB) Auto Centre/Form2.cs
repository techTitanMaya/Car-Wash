﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Venda_Boulevard__VB__Auto_Centre
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        int stereoSystem = 5999;
        int leatherInterior=29999;
        int computerNavigation =15900;
        int Standard=0;
        int Pearlized=9999;
        int customizedDetailing =12999;


        //Method to calculate amount due for  selecting all accesories
        private void salesCalculationMethod(decimal subtotal, decimal total, decimal amountDue, decimal salesTax, decimal taxRate = 0.15m)
        {
            try
            {
                decimal basePrice = decimal.Parse(txtBoxPrice.Text); 
                decimal tradeAllowance = decimal.Parse(txtBoxAllowance.Text);
                decimal.Parse(txtBoxAccFin.Text = "0");

                if (checkBoxStereo.Checked == true &
                   checkBoxLeather.Checked == true &
                   checkBoxNavigation.Checked == true &
                   radioButtonDetailing.Checked == true)
                {
                    subtotal = basePrice + stereoSystem + leatherInterior + computerNavigation + customizedDetailing;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (stereoSystem + leatherInterior + computerNavigation).ToString("c");
                }
                else if (checkBoxStereo.Checked == true &
                         checkBoxLeather.Checked == true &
                         radioButtonDetailing.Checked == true)
                {
                    subtotal = basePrice + stereoSystem + leatherInterior + customizedDetailing;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (stereoSystem + leatherInterior).ToString("c");
                }
                else if (checkBoxStereo.Checked == true &
                        checkBoxNavigation.Checked == true &
                        radioButtonDetailing.Checked == true)
                {
                    subtotal = basePrice + stereoSystem + computerNavigation + customizedDetailing;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (stereoSystem + computerNavigation).ToString("c");
                }
                else if (checkBoxLeather.Checked == true &
                        checkBoxNavigation.Checked == true &
                        radioButtonDetailing.Checked == true)
                {
                    subtotal = basePrice + leatherInterior + computerNavigation + customizedDetailing;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (leatherInterior + computerNavigation).ToString("c");
                }
                else if (checkBoxLeather.Checked == true &
                        radioButtonDetailing.Checked == true)
                {
                    subtotal = basePrice + leatherInterior + customizedDetailing;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (leatherInterior).ToString("c");
                }
                else if (checkBoxNavigation.Checked == true &
                        radioButtonDetailing.Checked == true)
                {
                    subtotal = basePrice + computerNavigation + customizedDetailing;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (computerNavigation).ToString("c");
                }
                else if (checkBoxStereo.Checked == true &
                        radioButtonDetailing.Checked == true)
                {
                    subtotal = basePrice + stereoSystem + customizedDetailing;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (stereoSystem).ToString("c");
                }
                else if (radioButtonDetailing.Checked == true)
                {
                    subtotal = basePrice + customizedDetailing;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                }

                // calculation for the pearlized exterior finish
                if (checkBoxStereo.Checked == true &
                   checkBoxLeather.Checked == true &
                   checkBoxNavigation.Checked == true &
                   radioButtonPearlized.Checked == true)
                {
                    subtotal = basePrice + stereoSystem + leatherInterior + computerNavigation + Pearlized;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (stereoSystem + leatherInterior + computerNavigation).ToString("c");
                }
                else if (checkBoxStereo.Checked == true &
                         checkBoxLeather.Checked == true &
                         radioButtonPearlized.Checked == true)
                {
                    subtotal = basePrice + stereoSystem + leatherInterior + Pearlized;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (stereoSystem + leatherInterior).ToString("c");
                }
                else if (checkBoxStereo.Checked == true &
                        checkBoxNavigation.Checked == true &
                        radioButtonPearlized.Checked == true)
                {
                    subtotal = basePrice + stereoSystem + computerNavigation + Pearlized;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (stereoSystem + computerNavigation).ToString("c");
                }
                else if (checkBoxLeather.Checked == true &
                        checkBoxNavigation.Checked == true &
                        radioButtonPearlized.Checked == true)
                {
                    subtotal = basePrice + leatherInterior + computerNavigation + Pearlized;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (leatherInterior + computerNavigation).ToString("c");
                }
                else if (checkBoxLeather.Checked == true &
                        radioButtonPearlized.Checked == true)
                {
                    subtotal = basePrice + leatherInterior + Pearlized;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (leatherInterior).ToString("c");
                }
                else if (checkBoxNavigation.Checked == true &
                        radioButtonPearlized.Checked == true)
                {
                    subtotal = basePrice + computerNavigation + Pearlized;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (computerNavigation).ToString("c");
                }
                else if (checkBoxStereo.Checked == true &
                        radioButtonPearlized.Checked == true)
                {
                    subtotal = basePrice + stereoSystem + Pearlized;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (stereoSystem).ToString("c");
                }
                else if (radioButtonPearlized.Checked == true)
                {
                    subtotal = basePrice + Pearlized;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;

                }
                // calculation for the standard exterior finish
                if (checkBoxStereo.Checked == true &
                           checkBoxLeather.Checked == true &
                           checkBoxNavigation.Checked == true &
                           radioButtonStandard.Checked == true)
                {
                    subtotal = basePrice + stereoSystem + leatherInterior + computerNavigation + Standard;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (stereoSystem + leatherInterior + computerNavigation).ToString("c");
                }
                else if (checkBoxStereo.Checked == true &
                         checkBoxLeather.Checked == true &
                         radioButtonStandard.Checked == true)
                {
                    subtotal = basePrice + stereoSystem + leatherInterior + Standard;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (stereoSystem + leatherInterior).ToString("c");
                }
                else if (checkBoxStereo.Checked == true &
                        checkBoxNavigation.Checked == true &
                        radioButtonStandard.Checked == true)
                {
                    subtotal = basePrice + stereoSystem + computerNavigation + Standard;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (stereoSystem + computerNavigation).ToString("c");
                }
                else if (checkBoxLeather.Checked == true &
                        checkBoxNavigation.Checked == true &
                        radioButtonStandard.Checked == true)
                {
                    subtotal = basePrice + leatherInterior + computerNavigation + Standard;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (leatherInterior + computerNavigation).ToString("c");
                }
                else if (checkBoxLeather.Checked == true &
                        radioButtonStandard.Checked == true)
                {
                    subtotal = basePrice + leatherInterior + Standard;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (leatherInterior).ToString("c");
                }
                else if (checkBoxNavigation.Checked == true &
                        radioButtonStandard.Checked == true)
                {
                    subtotal = basePrice + computerNavigation + Standard;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (computerNavigation).ToString("c");
                }
                else if (checkBoxStereo.Checked == true &
                        radioButtonStandard.Checked == true)
                {
                    subtotal = basePrice + stereoSystem + Standard;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                    txtBoxAccFin.Text = (stereoSystem).ToString("c");
                }
                else if (radioButtonStandard.Checked == true)
                {
                    subtotal = basePrice + Standard;
                    salesTax = subtotal * taxRate;
                    total = subtotal + salesTax;
                    amountDue = total - tradeAllowance;
                }

                txtBoxSubtotal.Text = string.Format(subtotal.ToString("c"));
                txtBoxDue.Text = string.Format(amountDue.ToString("c"));
                txtBoxTotal.Text = string.Format(total.ToString("c"));
                txtBoxTax.Text = string.Format(salesTax.ToString("c"));

            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid numeric format. Please check all entries.", "Entry Error");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message + "\n\n" +
                ex.GetType().ToString() + "\n" );
            }

        }
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void clearToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            txtBoxAccFin.Clear();
            txtBoxAllowance.Clear();
            txtBoxDue.Clear();
            txtBoxSubtotal.Clear();
            txtBoxTax.Clear();
            txtBoxPrice.Clear();
            txtBoxTotal.Clear();
            txtBoxPrice.Focus();
            
        }

        private void closeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Hide(); //closing this form takes you back to the first one
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.salesCalculationMethod(amountDue: 0, total: 0, salesTax: 0, subtotal: 0); // call the calculation method
        }

        private void btnSearch_Click(object sender, EventArgs e) // Go to the next form to search parts
        {
            Form3 formSearch = new Form3();
            formSearch.Show();

        }

        private void printToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            printPreviewDialogCalculation.Document = printDocumentCalculation;
            printPreviewDialogCalculation.ShowDialog();
        }

        //Print the order total
        private void printDocumentCalculation_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            string text = "The total cost of your order is " + txtBoxDue.Text ;
            Font printFont = new System.Drawing.Font("Arial", 20, System.Drawing.FontStyle.Regular);


            // Draw the string .
            e.Graphics.DrawString(text, printFont, Brushes.Black, 100, 100);
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 form = new Form5();
            form.Show();
        }
    }
    }

