﻿namespace Venda_Boulevard__VB__Auto_Centre
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblPartNumber = new System.Windows.Forms.Label();
            this.txtBoxBrandPartNumber = new System.Windows.Forms.TextBox();
            this.groupBoxBrands = new System.Windows.Forms.GroupBox();
            this.radioButtonX = new System.Windows.Forms.RadioButton();
            this.radioButtonC = new System.Windows.Forms.RadioButton();
            this.radioButtonA = new System.Windows.Forms.RadioButton();
            this.textBoxVBAutoNumber = new System.Windows.Forms.TextBox();
            this.lblAutoNumber = new System.Windows.Forms.Label();
            this.btnLookup = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBoxBrands.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.lblPartNumber);
            this.groupBox1.Controls.Add(this.txtBoxBrandPartNumber);
            this.groupBox1.Controls.Add(this.groupBoxBrands);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(13, 12);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Size = new System.Drawing.Size(455, 245);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select Brand and Enter Part Number";
            // 
            // lblPartNumber
            // 
            this.lblPartNumber.AutoSize = true;
            this.lblPartNumber.ForeColor = System.Drawing.Color.Black;
            this.lblPartNumber.Location = new System.Drawing.Point(296, 58);
            this.lblPartNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPartNumber.Name = "lblPartNumber";
            this.lblPartNumber.Size = new System.Drawing.Size(151, 15);
            this.lblPartNumber.TabIndex = 3;
            this.lblPartNumber.Text = "Enter the part number:";
            // 
            // txtBoxBrandPartNumber
            // 
            this.txtBoxBrandPartNumber.Location = new System.Drawing.Point(301, 86);
            this.txtBoxBrandPartNumber.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtBoxBrandPartNumber.Name = "txtBoxBrandPartNumber";
            this.txtBoxBrandPartNumber.Size = new System.Drawing.Size(116, 21);
            this.txtBoxBrandPartNumber.TabIndex = 4;
            // 
            // groupBoxBrands
            // 
            this.groupBoxBrands.Controls.Add(this.radioButtonX);
            this.groupBoxBrands.Controls.Add(this.radioButtonC);
            this.groupBoxBrands.Controls.Add(this.radioButtonA);
            this.groupBoxBrands.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBoxBrands.ForeColor = System.Drawing.Color.Black;
            this.groupBoxBrands.Location = new System.Drawing.Point(7, 40);
            this.groupBoxBrands.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBoxBrands.Name = "groupBoxBrands";
            this.groupBoxBrands.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBoxBrands.Size = new System.Drawing.Size(150, 188);
            this.groupBoxBrands.TabIndex = 0;
            this.groupBoxBrands.TabStop = false;
            this.groupBoxBrands.Text = "Brand";
            // 
            // radioButtonX
            // 
            this.radioButtonX.AutoSize = true;
            this.radioButtonX.Location = new System.Drawing.Point(7, 154);
            this.radioButtonX.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButtonX.Name = "radioButtonX";
            this.radioButtonX.Size = new System.Drawing.Size(76, 19);
            this.radioButtonX.TabIndex = 2;
            this.radioButtonX.TabStop = true;
            this.radioButtonX.Text = "Brand X";
            this.radioButtonX.UseVisualStyleBackColor = true;
            // 
            // radioButtonC
            // 
            this.radioButtonC.AutoSize = true;
            this.radioButtonC.Location = new System.Drawing.Point(4, 86);
            this.radioButtonC.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButtonC.Name = "radioButtonC";
            this.radioButtonC.Size = new System.Drawing.Size(76, 19);
            this.radioButtonC.TabIndex = 1;
            this.radioButtonC.TabStop = true;
            this.radioButtonC.Text = "Brand C";
            this.radioButtonC.UseVisualStyleBackColor = true;
            // 
            // radioButtonA
            // 
            this.radioButtonA.AutoSize = true;
            this.radioButtonA.Location = new System.Drawing.Point(4, 33);
            this.radioButtonA.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButtonA.Name = "radioButtonA";
            this.radioButtonA.Size = new System.Drawing.Size(75, 19);
            this.radioButtonA.TabIndex = 0;
            this.radioButtonA.TabStop = true;
            this.radioButtonA.Text = "Brand A";
            this.radioButtonA.UseVisualStyleBackColor = true;
            // 
            // textBoxVBAutoNumber
            // 
            this.textBoxVBAutoNumber.Location = new System.Drawing.Point(575, 115);
            this.textBoxVBAutoNumber.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBoxVBAutoNumber.Name = "textBoxVBAutoNumber";
            this.textBoxVBAutoNumber.ReadOnly = true;
            this.textBoxVBAutoNumber.Size = new System.Drawing.Size(142, 20);
            this.textBoxVBAutoNumber.TabIndex = 1;
            // 
            // lblAutoNumber
            // 
            this.lblAutoNumber.AutoSize = true;
            this.lblAutoNumber.BackColor = System.Drawing.Color.Transparent;
            this.lblAutoNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAutoNumber.ForeColor = System.Drawing.Color.Black;
            this.lblAutoNumber.Location = new System.Drawing.Point(572, 85);
            this.lblAutoNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAutoNumber.Name = "lblAutoNumber";
            this.lblAutoNumber.Size = new System.Drawing.Size(145, 15);
            this.lblAutoNumber.TabIndex = 2;
            this.lblAutoNumber.Text = "VB Auto Part Number:";
            // 
            // btnLookup
            // 
            this.btnLookup.Location = new System.Drawing.Point(315, 323);
            this.btnLookup.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnLookup.Name = "btnLookup";
            this.btnLookup.Size = new System.Drawing.Size(88, 23);
            this.btnLookup.TabIndex = 5;
            this.btnLookup.Text = "Lookup";
            this.btnLookup.UseVisualStyleBackColor = true;
            this.btnLookup.Click += new System.EventHandler(this.btnLookup_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(440, 323);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(88, 23);
            this.btnClear.TabIndex = 6;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(565, 323);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(88, 23);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form3
            // 
            this.AcceptButton = this.btnLookup;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(793, 364);
            this.Controls.Add(this.btnLookup);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblAutoNumber);
            this.Controls.Add(this.textBoxVBAutoNumber);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form3";
            this.Text = "VB Auto Centre";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBoxBrands.ResumeLayout(false);
            this.groupBoxBrands.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblPartNumber;
        private System.Windows.Forms.TextBox txtBoxBrandPartNumber;
        private System.Windows.Forms.GroupBox groupBoxBrands;
        private System.Windows.Forms.RadioButton radioButtonX;
        private System.Windows.Forms.RadioButton radioButtonC;
        private System.Windows.Forms.RadioButton radioButtonA;
        private System.Windows.Forms.TextBox textBoxVBAutoNumber;
        private System.Windows.Forms.Label lblAutoNumber;
        private System.Windows.Forms.Button btnLookup;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
    }
}