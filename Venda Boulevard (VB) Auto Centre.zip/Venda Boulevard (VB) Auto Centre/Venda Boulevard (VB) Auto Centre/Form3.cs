﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Venda_Boulevard__VB__Auto_Centre
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        string[] VBAuto = {"PR214","PR223","PR224","PR246","PR247","PR248","PR324","PR326","PR444" };
        string[] BrandA = {"MR43T","R43","R43N","R46N","R46TS","R46TX","S46","SR46E","47L"};
        string[] BrandC = {"RBL8","RJ6","RN4","RN8","RBL17Y","RBL12-6","J11","XEJ8","H12" };
        string[] BrandX= { "14K22", "14K24" , "14K30" , "14K44" , "14K33" , "14K35" , "14K38", "14K40","14K44" };

        private void btnLookup_Click(object sender, EventArgs e)
        {
           if (radioButtonA.Checked==true)
            if (txtBoxBrandPartNumber.Text == BrandA[0])
            { textBoxVBAutoNumber.Text = VBAuto[0]; }
            else if (txtBoxBrandPartNumber.Text == BrandA[1])
            { textBoxVBAutoNumber.Text = VBAuto[1]; }
            else if (txtBoxBrandPartNumber.Text == BrandA[2])
            { textBoxVBAutoNumber.Text = VBAuto[2]; }
            else if (txtBoxBrandPartNumber.Text == BrandA[3])
            { textBoxVBAutoNumber.Text = VBAuto[3]; }
            else if (txtBoxBrandPartNumber.Text == BrandA[4])
            { textBoxVBAutoNumber.Text = VBAuto[4]; }
            else if (txtBoxBrandPartNumber.Text == BrandA[5])
            { textBoxVBAutoNumber.Text = VBAuto[5]; }
            else if (txtBoxBrandPartNumber.Text == BrandA[6])
            { textBoxVBAutoNumber.Text = VBAuto[6]; }
            else if (txtBoxBrandPartNumber.Text == BrandA[7])
            { textBoxVBAutoNumber.Text = VBAuto[7]; }
            else if (txtBoxBrandPartNumber.Text == BrandA[8])
            { textBoxVBAutoNumber.Text = VBAuto[8]; }
           
           
            
           if(radioButtonC.Checked==true)
            if (txtBoxBrandPartNumber.Text == BrandC[0])
            { textBoxVBAutoNumber.Text = VBAuto[0]; }
            else if (txtBoxBrandPartNumber.Text == BrandC[1])
            { textBoxVBAutoNumber.Text = VBAuto[1]; }
            else if (txtBoxBrandPartNumber.Text == BrandC[2])
            { textBoxVBAutoNumber.Text = VBAuto[2]; }
            else if (txtBoxBrandPartNumber.Text == BrandC[3])
            { textBoxVBAutoNumber.Text = VBAuto[3]; }
            else if (txtBoxBrandPartNumber.Text == BrandC[4])
            { textBoxVBAutoNumber.Text = VBAuto[4]; }
            else if (txtBoxBrandPartNumber.Text == BrandC[5])
            { textBoxVBAutoNumber.Text = VBAuto[5]; }
            else if (txtBoxBrandPartNumber.Text == BrandC[6])
            { textBoxVBAutoNumber.Text = VBAuto[6]; }
            else if (txtBoxBrandPartNumber.Text == BrandC[7])
            { textBoxVBAutoNumber.Text = VBAuto[7]; }
            else if (txtBoxBrandPartNumber.Text == BrandC[8])
            { textBoxVBAutoNumber.Text = VBAuto[8]; }
            


           if(radioButtonX.Checked==true)
            if (txtBoxBrandPartNumber.Text == BrandX[0])
            { textBoxVBAutoNumber.Text = VBAuto[0]; }
            else if (txtBoxBrandPartNumber.Text == BrandX[1])
            { textBoxVBAutoNumber.Text = VBAuto[1]; }
            else if (txtBoxBrandPartNumber.Text == BrandX[2])
            { textBoxVBAutoNumber.Text = VBAuto[2]; }
            else if (txtBoxBrandPartNumber.Text == BrandX[3])
            { textBoxVBAutoNumber.Text = VBAuto[3]; }
            else if (txtBoxBrandPartNumber.Text == BrandX[4])
            { textBoxVBAutoNumber.Text = VBAuto[4]; }
            else if (txtBoxBrandPartNumber.Text == BrandX[5])
            { textBoxVBAutoNumber.Text = VBAuto[5]; }
            else if (txtBoxBrandPartNumber.Text == BrandX[6])
            { textBoxVBAutoNumber.Text = VBAuto[6]; }
            else if (txtBoxBrandPartNumber.Text == BrandX[7])
            { textBoxVBAutoNumber.Text = VBAuto[7]; }
            else if (txtBoxBrandPartNumber.Text == BrandX[8])
            { textBoxVBAutoNumber.Text = VBAuto[8]; }
           

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtBoxBrandPartNumber.Clear();
            textBoxVBAutoNumber.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
